<?php  echo $footer;  ?><div class="footer">
	COPYRIGHT ©
	<a href="<?php  echo $host;  ?>"><?php  echo $copyright;  ?></a>
	| Powered By 
	<a><?php  echo $zblogphphtml;  ?></a>
</div>
