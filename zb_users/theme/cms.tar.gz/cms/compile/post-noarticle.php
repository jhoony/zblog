<div class="containter" style="margin-left: 340px;">
	<div class="article-list">
		<article class="article">
			<h1>亲,您还未新建任何文章哦！</h1>
			<div class="aside">follow me！开启新建文章之旅。。。</div>
		</article>

		<div class="footer">
			COPYRIGHT ©
			<a href="<?php  echo $host;  ?>"><?php  echo $copyright;  ?></a>
			| Powered By 
			<a><?php  echo $zblogphphtml;  ?></a>
		</div>
	</div
</div>