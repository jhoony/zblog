<?php  foreach ( $sidebar as $module) { ?> 
<?php  include $this->GetTemplate('module');  ?>
<?php  }   ?>