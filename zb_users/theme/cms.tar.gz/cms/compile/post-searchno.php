
		<article class="article">
			<h1>Sorry,还没发表过"fdsafasdfas"相关的内容</h1>
			<div class="aside">没有文章</div>
		</article>

		<div class="footer">
			COPYRIGHT ©
			<a href="<?php  echo $host;  ?>"><?php  echo $copyright;  ?></a>
			| Powered By 
			<a><?php  echo $zblogphphtml;  ?></a>
		</div>
		<?php  include $this->GetTemplate('post-slide');  ?>
