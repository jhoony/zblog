<div class="footer">
	COPYRIGHT ©
	<a href="{$host}">{$copyright}</a>
	| Powered By 
	<a>{$zblogphphtml}</a>
</div>
