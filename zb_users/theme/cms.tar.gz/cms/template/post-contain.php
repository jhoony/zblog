
			<div class="pagenavi">
				<a href="{$pagebar.prevbutton}">«</a>
				<a class="page-numbers" href="">1</a>
				<span class="page-numbers current">2</span>
				<a class="page-numbers" href="">3</a>
				<a href="{$pagebar.nextbutton}">»</a>
				<div class="clear">
				</div>
			</div>
